import * as THREE from 'three';

// Visual particle effects for web impacts, landing dust, and high-speed air trails
export class VFXManager {
  constructor(scene) {
    this.scene = scene;
    this.particles = [];

    // Particle pool
    const count = 250;
    const geom = new THREE.BufferGeometry();
    this.positions = new Float32Array(count * 3);
    this.colors = new Float32Array(count * 3);
    this.sizes = new Float32Array(count);

    geom.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    geom.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));

    const mat = new THREE.PointsMaterial({
      size: 0.8,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });

    this.pointsMesh = new THREE.Points(geom, mat);
    this.scene.add(this.pointsMesh);

    for (let i = 0; i < count; i++) {
      this.particles.push({
        active: false,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        color: new THREE.Color(),
        life: 0,
        maxLife: 1,
        size: 1
      });
    }
  }

  spawnWebImpact(pos) {
    let spawned = 0;
    for (let i = 0; i < this.particles.length && spawned < 18; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.pos.copy(pos);
        p.vel.set(
          (Math.random() - 0.5) * 6,
          (Math.random() - 0.5) * 6,
          (Math.random() - 0.5) * 6
        );
        p.color.setRGB(1.0, 1.0, 1.0); // Bright white web strands
        p.life = 0;
        p.maxLife = 0.35 + Math.random() * 0.25;
        p.size = 1.2;
        spawned++;
      }
    }
  }

  spawnLandingDust(pos) {
    let spawned = 0;
    for (let i = 0; i < this.particles.length && spawned < 25; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.pos.copy(pos);
        const angle = Math.random() * Math.PI * 2;
        const spd = 4 + Math.random() * 8;
        p.vel.set(Math.cos(angle) * spd, 1 + Math.random() * 3, Math.sin(angle) * spd);
        p.color.setRGB(0.8, 0.75, 0.7); // Concrete dust
        p.life = 0;
        p.maxLife = 0.5 + Math.random() * 0.3;
        p.size = 1.6;
        spawned++;
      }
    }
  }

  update(delta) {
    const posAttr = this.pointsMesh.geometry.attributes.position;
    const colAttr = this.pointsMesh.geometry.attributes.color;

    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (p.active) {
        p.life += delta;
        if (p.life >= p.maxLife) {
          p.active = false;
          posAttr.setXYZ(i, 0, -9999, 0); // Hide offscreen
          continue;
        }

        p.pos.addScaledVector(p.vel, delta);
        p.vel.y -= 9.8 * delta; // Gravity on particles

        const alpha = 1.0 - p.life / p.maxLife;
        posAttr.setXYZ(i, p.pos.x, p.pos.y, p.pos.z);
        colAttr.setXYZ(i, p.color.r * alpha, p.color.g * alpha, p.color.b * alpha);
      } else {
        posAttr.setXYZ(i, 0, -9999, 0);
      }
    }

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
  }
}
