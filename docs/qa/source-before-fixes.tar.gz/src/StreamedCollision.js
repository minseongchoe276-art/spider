import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';

const initialized = RAPIER.init();

export class StreamedCollision {
  constructor() {
    this.ready = false;
    this.meshes = new Map();
    this.pending = [];
    this.center = new THREE.Vector3();
    this.initialized = initialized.then(() => {
      this.world = new RAPIER.World({ x: 0, y: 0, z: 0 });
      this.body = this.world.createCollider(RAPIER.ColliderDesc.capsule(0.55, 0.35));
      this.controller = this.world.createCharacterController(0.025);
      this.controller.enableAutostep(0.3, 0.25, false);
      this.controller.enableSnapToGround(0.15);
      this.controller.setMaxSlopeClimbAngle(Math.PI / 4);
      this.controller.setMinSlopeSlideAngle(Math.PI / 3);
      this.ready = true;
    });
  }

  enqueue(mesh) {
    if (!this.meshes.has(mesh.uuid)) {
      this.meshes.set(mesh.uuid, null);
      this.pending.push(mesh);
    }
  }

  setActiveMeshes(meshes) { this.activeMeshes = new Set(meshes.map(mesh=>mesh.uuid)); }

  raycast(origin, direction, maxDistance, solid = true) {
    if (!this.ready || maxDistance <= 0) return null;
    const dir = direction.clone().normalize();
    const hit = this.world.castRayAndGetNormal(
      new RAPIER.Ray(
        { x:origin.x,y:origin.y,z:origin.z },
        { x:dir.x,y:dir.y,z:dir.z },
      ),
      maxDistance,
      solid,
      undefined,
      undefined,
      this.body,
    );
    if (!hit) return null;
    const normal = new THREE.Vector3(hit.normal.x,hit.normal.y,hit.normal.z);
    return {
      distance: hit.timeOfImpact,
      point: origin.clone().addScaledVector(dir,hit.timeOfImpact),
      normal,
      collider: hit.collider,
    };
  }

  update(center) {
    this.center.copy(center);
    if (!this.ready) return;
    if (this.activeMeshes) {
      const now = performance.now();
      for (const [id, entry] of this.meshes) {
        if (!entry) continue;
        if (this.activeMeshes.has(id)) entry.inactiveSince = null;
        else {
          entry.inactiveSince ??= now;
          if (now-entry.inactiveSince>2000) {
            this.world.removeCollider(entry.collider,true); this.meshes.delete(id);
          }
        }
      }
    }
    if ((this.priorityFrame = (this.priorityFrame || 0) + 1) % 30 === 1) {
      for (const candidate of this.pending) {
        candidate.updateWorldMatrix(true, false);
        candidate.geometry.computeBoundingBox();
        candidate.userData.collisionPriority = candidate.geometry.boundingBox.clone()
          .applyMatrix4(candidate.matrixWorld).distanceToPoint(center);
      }
      this.pending.sort((a,b)=>a.userData.collisionPriority-b.userData.collisionPriority);
    }
    // One tile mesh per frame bounds the main-thread conversion work.
    const mesh = this.pending.shift();
    if (mesh && this.activeMeshes && !this.activeMeshes.has(mesh.uuid)) {
      this.meshes.delete(mesh.uuid); return;
    }
    if (mesh?.geometry?.attributes.position) {
      mesh.updateWorldMatrix(true, false);
      const geometry = mesh.geometry, attribute = geometry.attributes.position;
      const vertices = [], indices = [];
      const index = geometry.index;
      const count = index ? index.count : attribute.count;
      const mapped = new Int32Array(attribute.count);
      mapped.fill(-1);
      const triangle = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
      const minX=center.x-650,maxX=center.x+650,minZ=center.z-650,maxZ=center.z+650;
      // Retain triangles in the current local neighbourhood. Coordinates are
      // transformed by the same world matrix used for rendering the city.
      for (let i = 0; i + 2 < count; i += 3) {
        for (let n = 0; n < 3; n++) {
          triangle[n].fromBufferAttribute(attribute, index ? index.getX(i + n) : i + n)
            .applyMatrix4(mesh.matrixWorld);
        }
        let triMinX=Infinity,triMaxX=-Infinity,triMinZ=Infinity,triMaxZ=-Infinity;
        for (const p of triangle) {
          triMinX=Math.min(triMinX,p.x); triMaxX=Math.max(triMaxX,p.x);
          triMinZ=Math.min(triMinZ,p.z); triMaxZ=Math.max(triMaxZ,p.z);
        }
        if (triMaxX<minX || triMinX>maxX || triMaxZ<minZ || triMinZ>maxZ) continue;
        for (let n=0;n<3;n++) {
          const original = index ? index.getX(i+n) : i+n;
          if (mapped[original] === -1) {
            mapped[original] = vertices.length / 3;
            const p=triangle[n]; vertices.push(p.x,p.y,p.z);
          }
          indices.push(mapped[original]);
        }
      }
      if (indices.length) {
        const collider = this.world.createCollider(RAPIER.ColliderDesc.trimesh(
          new Float32Array(vertices), new Uint32Array(indices)));
        this.meshes.set(mesh.uuid, { collider, center: new THREE.Box3().setFromObject(mesh).getCenter(new THREE.Vector3()) });
        this.world.step();
      }
      else this.meshes.delete(mesh.uuid);
    } else if (mesh) this.meshes.delete(mesh.uuid);
    // Keep collision meshes when a visual LOD unloads, but bound retained
    // memory; dispose distant geometry before evicting local support surfaces.
    if (this.meshes.size > 350) {
      for (const [id, entry] of this.meshes) {
        if (entry && entry.center.distanceTo(center) > 900) {
          this.world.removeCollider(entry.collider, true); this.meshes.delete(id);
        }
      }
    }
  }

  resolve(start, end, velocity) {
    if (!this.ready) return { position: start.clone(), contacts: [] };
    this.body.setTranslation({ x: start.x, y: start.y + 0.8, z: start.z });
    this.world.step();
    const delta = end.clone().sub(start);
    if (delta.y > 0) this.controller.disableSnapToGround();
    else this.controller.enableSnapToGround(0.15);
    this.controller.computeColliderMovement(this.body, delta, undefined, undefined,
      collider => collider.handle !== this.body.handle);
    const movement = this.controller.computedMovement();
    const contacts = [];
    for (let i = 0; i < this.controller.numComputedCollisions(); i++) {
      const contact = this.controller.computedCollision(i);
      const normal = new THREE.Vector3(contact.normal1.x, contact.normal1.y, contact.normal1.z);
      contacts.push({ normal });
      const inward = velocity.dot(normal);
      if (inward < 0) velocity.addScaledVector(normal, -inward);
    }
    return { position: start.clone().add(new THREE.Vector3(movement.x, movement.y, movement.z)),
      contacts, grounded: this.controller.computedGrounded() };
  }

  groundAt(position, range = 1) {
    if (!this.ready) return null;
    const hit = this.world.castRayAndGetNormal(new RAPIER.Ray(
      { x: position.x, y: position.y + 0.25, z: position.z }, { x: 0, y: -1, z: 0 }),
      range + 0.25, false, undefined, undefined, this.body);
    this.lastGroundHit = hit ? { normal:hit.normal, distance:hit.timeOfImpact,
      pointY:position.y+0.25-hit.timeOfImpact } : null;
    if (!hit || hit.normal.y < Math.cos(Math.PI / 4)) return null;
    return position.y + 0.25 - hit.timeOfImpact;
  }
}
