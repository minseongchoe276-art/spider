import * as THREE from 'three';

// Glowing neon checkpoint rings for Time Trial course through skyscraper canyons
export class TimeTrialSystem {
  constructor(scene, city, audio) {
    this.scene = scene;
    this.city = city;
    this.audio = audio;

    this.isActive = false;
    this.checkpoints = [];
    this.currentIndex = 0;
    this.startTime = 0;
    this.elapsedTime = 0;
    this.isCompleted = false;

    this.ringMeshGroup = new THREE.Group();
    this.ringMeshGroup.name = 'TimeTrialRings';
    this.scene.add(this.ringMeshGroup);

    this.initRingGeometry();
    this.createCourse();
  }

  initRingGeometry() {
    // Torus ring for glowing checkpoints
    this.ringGeom = new THREE.TorusGeometry(3.6, 0.35, 12, 32);
    this.activeMat = new THREE.MeshBasicMaterial({
      color: 0xffb703,
      transparent: true,
      opacity: 0.95
    });
    this.inactiveMat = new THREE.MeshBasicMaterial({
      color: 0x334466,
      transparent: true,
      opacity: 0.4
    });
    this.nextMat = new THREE.MeshBasicMaterial({
      color: 0x00d2ff,
      transparent: true,
      opacity: 0.8
    });
  }

  createCourse() {
    // 8 Checkpoints weaving through the skyscraper alleys at varied swing altitudes
    const ringCoords = [
      new THREE.Vector3(0, 70, 40),
      new THREE.Vector3(50, 55, 100),
      new THREE.Vector3(120, 65, 80),
      new THREE.Vector3(140, 45, 0),
      new THREE.Vector3(80, 50, -80),
      new THREE.Vector3(-40, 60, -100),
      new THREE.Vector3(-100, 75, -20),
      new THREE.Vector3(0, 95, 0) // Finish at top of central skyscraper
    ];

    ringCoords.forEach((pos, idx) => {
      const mesh = new THREE.Mesh(this.ringGeom, idx === 0 ? this.activeMat : this.inactiveMat);
      mesh.position.copy(pos);
      // Face towards next checkpoint
      if (idx < ringCoords.length - 1) {
        mesh.lookAt(ringCoords[idx + 1]);
      } else {
        mesh.rotation.y = Math.PI / 2;
      }
      mesh.visible = false; // Hidden until mode activated
      this.ringMeshGroup.add(mesh);

      this.checkpoints.push({
        position: pos,
        mesh: mesh,
        index: idx,
        radius: 4.8
      });
    });
  }

  start() {
    this.isActive = true;
    this.isCompleted = false;
    this.currentIndex = 0;
    this.startTime = performance.now();
    this.elapsedTime = 0;

    // Show rings
    this.checkpoints.forEach((cp, idx) => {
      cp.mesh.visible = true;
      cp.mesh.material = idx === 0 ? this.activeMat : (idx === 1 ? this.nextMat : this.inactiveMat);
    });

    return true;
  }

  stop() {
    this.isActive = false;
    this.checkpoints.forEach(cp => {
      cp.mesh.visible = false;
    });
  }

  toggle() {
    if (this.isActive) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }

  update(playerPos) {
    if (!this.isActive || this.isCompleted) return null;

    this.elapsedTime = (performance.now() - this.startTime) / 1000;

    const currentCp = this.checkpoints[this.currentIndex];
    if (currentCp) {
      // Pulse animation on active ring
      const scale = 1.0 + Math.sin(this.elapsedTime * 6) * 0.1;
      currentCp.mesh.scale.set(scale, scale, scale);

      // Check if player passed through ring
      const dist = playerPos.distanceTo(currentCp.position);
      if (dist < currentCp.radius) {
        // Checkpoint passed!
        this.audio.playCheckpointChime();
        currentCp.mesh.visible = false;
        this.currentIndex++;

        if (this.currentIndex >= this.checkpoints.length) {
          // Completed Course!
          this.isCompleted = true;
          return {
            completed: true,
            totalTime: this.elapsedTime,
            checkpoints: this.checkpoints.length
          };
        } else {
          // Update next ring material
          this.checkpoints[this.currentIndex].mesh.material = this.activeMat;
          if (this.currentIndex + 1 < this.checkpoints.length) {
            this.checkpoints[this.currentIndex + 1].mesh.material = this.nextMat;
          }
        }
      }
    }

    return {
      completed: false,
      currentIndex: this.currentIndex,
      totalCount: this.checkpoints.length,
      elapsedTime: this.elapsedTime
    };
  }
}
