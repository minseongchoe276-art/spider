import * as THREE from 'three';
import { City } from './City.js';
import { Character } from './Character.js';
import { SwingPhysics } from './SwingPhysics.js';
import { ThirdPersonCamera } from './Camera.js';
import { SoundController } from './Audio.js';
import { SpeedLinesEffect } from './SpeedLines.js';
import { TimeTrialSystem } from './TimeTrial.js';
import { VFXManager } from './VFX.js';
import { UrbanGroundCity } from './UrbanGroundCity.js';

class GameApp {
  constructor() {
    // 1. Locate or create Canvas elements
    const container = document.getElementById('game-container') || document.body;
    let canvas = document.getElementById('webgl-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'webgl-canvas';
      container.prepend(canvas);
    }
    this.canvas = canvas;

    this.speedLinesCanvas =
      document.getElementById('speedlines-canvas') ||
      document.getElementById('speed-lines-canvas');

    this.isPlaying = false;
    this.isPaused = false;
    this.cameraDragActive = false;
    this.lastMousePosition = null;

    this.input = {
      forward: false,
      backward: false,
      left: false,
      right: false,
      sprint: false,
      jump: false,
      webHold: false,
      webTap: false,
      wallRun: false,
      strafe: 0
    };

    // HUD Elements Cache
    this.speedDisplay = document.getElementById('speed-display');
    this.speedBarFill = document.getElementById('speed-bar-fill');
    this.altDisplay = document.getElementById('alt-display');
    this.altBarFill = document.getElementById('alt-bar-fill');
    this.webStatusDot = document.getElementById('web-status-dot');
    this.webStatusText = document.getElementById('web-status-text');
    this.crosshair = document.getElementById('crosshair');

    // Loading Screen Elements
    this.loadingScreen = document.getElementById('loading-screen');
    this.loadingBarFill = document.getElementById('loading-bar-fill');
    this.loadingPct = document.getElementById('loading-pct');
    this.loadingDesc = document.getElementById('loading-desc');
    this.clickToPlayOverlay = document.getElementById('overlay-click-to-play');

    this.initThree();
    this.initSystems();
    this.initInputListeners();
    this.initUIListeners();

    // Start render loop
    this.clock = new THREE.Clock();
    this.animate = this.animate.bind(this);
    requestAnimationFrame(this.animate);
  }

  initThree() {
    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.3;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x8fc8e8);
    // Stream the nearby district, not twenty kilometres of textured terrain
    // into the startup cache. The neighbourhood advances with the player.
    this.scene.fog = new THREE.FogExp2(0xaed9eb, 0.0004);

    // Camera
    this.camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.2, 1000);

    // Lighting
    const ambientLight = new THREE.HemisphereLight(0xd8f1ff, 0x536273, 1.25);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff8e8, 3.2);
    sunLight.position.set(160, 280, 140);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 50;
    sunLight.shadow.camera.far = 600;
    const shadowD = 180;
    sunLight.shadow.camera.left = -shadowD;
    sunLight.shadow.camera.right = shadowD;
    sunLight.shadow.camera.top = shadowD;
    sunLight.shadow.camera.bottom = -shadowD;
    sunLight.shadow.bias = -0.0003;
    this.scene.add(sunLight);

    // Sky Dome Gradient
    const skyGeom = new THREE.SphereGeometry(1900, 32, 16);
    const skyMat = new THREE.MeshBasicMaterial({
      color: 0x9bd5f0,
      side: THREE.BackSide
    });
    const sky = new THREE.Mesh(skyGeom, skyMat);
    this.scene.add(sky);

    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }

  initSystems() {
    this.audio = new SoundController();
    if (this.speedLinesCanvas) {
      this.speedLines = new SpeedLinesEffect(this.speedLinesCanvas);
    }

    const useUrbanGround = new URLSearchParams(location.search).get('city') !== 'procedural';
    this.city = useUrbanGround
      ? new UrbanGroundCity(this.scene, this.camera, this.renderer, (pct, desc) => {
        this.updateLoadingProgress(pct, desc);
      })
      : new City(this.scene);

    this.updateLoadingProgress(25, useUrbanGround
      ? 'UrbanGround 홍콩 3D 도시 스트리밍 연결 중...'
      : '도시 마천루 및 지형 생성 완료...');

    // Initialize character with loading callbacks
    this.character = new Character(
      this.scene,
      (pct, desc) => {
        this.updateLoadingProgress(pct, desc);
      },
      () => {
        this.onAssetsLoaded();
      }
    );

    this.vfx = new VFXManager(this.scene);
    this.physics = new SwingPhysics(this.scene, this.city, this.character, this.audio);
    this.physics.onLanding = (position, impact) => {
      if (impact > 7) this.vfx.spawnLandingDust(position);
      this.tpsCamera?.triggerShake(Math.min(0.6, impact / 70));
    };
    this.tpsCamera = new ThirdPersonCamera(this.camera, this.canvas);
    this.character.setFirstPersonCamera(this.camera);
    this.timeTrial = new TimeTrialSystem(this.scene, this.city, this.audio);

    // Set initial spawn on tall central building
    const spawn = this.city.getRooftopSpawn(95);
    this.physics.position.copy(spawn);
    this.physics.previousFixedPosition.copy(spawn);
    this.physics.renderPosition.copy(spawn);
    this.physics.velocity.set(0, 0, 0);
    this.physics.state = 'IDLE';
    this.tpsCamera.currentPos.copy(spawn.clone().add(new THREE.Vector3(0, 3, -7)));
    this.tpsCamera.lookAtTarget.copy(spawn.clone().add(new THREE.Vector3(0, 1.7, 0)));
    this.camera.position.copy(this.tpsCamera.currentPos);
    this.camera.lookAt(this.tpsCamera.lookAtTarget);
    this.camera.updateMatrixWorld(true);

    // Stunt callback
    this.physics.onStuntCallback = (name, pts) => {
      this.showStuntNotice(name, pts);
    };
  }

  updateLoadingProgress(pct, desc) {
    if (this.loadingBarFill) this.loadingBarFill.style.width = `${pct}%`;
    if (this.loadingPct) this.loadingPct.textContent = `${pct}%`;
    if (this.loadingDesc && desc) this.loadingDesc.textContent = desc;
  }

  onAssetsLoaded() {
    if (this.city instanceof UrbanGroundCity && !this.city.isReady) {
      this.updateLoadingProgress(75, '홍콩 도시의 건물·도로와 충돌 지형을 준비 중...');
      return;
    }
    if (this.assetsReady) return;
    this.assetsReady = true;
    if (this.city instanceof UrbanGroundCity) {
      this.physics.resetPosition();
      this.tpsCamera.currentPos.copy(this.physics.position).add(new THREE.Vector3(0,3,-7));
      this.tpsCamera.lookAtTarget.copy(this.physics.position).add(new THREE.Vector3(0,1.7,0));
    }
    this.updateLoadingProgress(100, '준비 완료!');
    setTimeout(() => {
      if (this.loadingScreen) {
        this.loadingScreen.classList.add('hidden');
      }
      if (this.clickToPlayOverlay) {
        this.clickToPlayOverlay.classList.remove('hidden');
      }
    }, 400);
  }

  initInputListeners() {
    // Keyboard
    window.addEventListener('blur', () => { this.clearInput(); if (this.isPlaying) this.setPaused(true); });
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.clearInput(); });
    window.addEventListener('keydown', (e) => {
      const k = e.code;
      const gameplayKey = [
        'KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown',
        'ArrowLeft', 'ArrowRight', 'ShiftLeft', 'ShiftRight', 'Space',
        'KeyE', 'KeyT', 'KeyF', 'KeyC', 'KeyV'
      ].includes(k);
      if (gameplayKey && (!this.isPlaying || this.isPaused)) return;
      if (gameplayKey) e.preventDefault();
      if (gameplayKey && e.repeat && ['Space','KeyE','KeyT','KeyC','KeyV'].includes(k)) return;

      if (k === 'KeyW' || k === 'ArrowUp') this.input.forward = true;
      if (k === 'KeyS' || k === 'ArrowDown') this.input.backward = true;
      if (k === 'KeyA' || k === 'ArrowLeft') { this.input.left = true; this.input.strafe = -1; }
      if (k === 'KeyD' || k === 'ArrowRight') { this.input.right = true; this.input.strafe = 1; }
      if (k === 'ShiftLeft' || k === 'ShiftRight') this.input.sprint = true;
      if (!e.repeat && k === 'KeyC') {
        if (this.tpsCamera.mode === 'first') {
          this.tpsCamera.mode = 'follow';
          this.character.setFirstPersonMode(false);
          this.showCameraMode('follow');
        }
        this.tpsCamera.recenterBehind(this.physics.facingAngle);
      }
      if (!e.repeat && k === 'KeyV') {
        const previousMode = this.tpsCamera.mode;
        const mode = this.tpsCamera.cycleMode();
        if (mode === 'first') {
          this.tpsCamera.yaw = this.physics.facingAngle;
          this.tpsCamera.pitch = 0;
          this.tpsCamera.lockBehind = false;
          this.tpsCamera.orbitReturnTime = Infinity;
        } else if (previousMode === 'first') {
          this.tpsCamera.lockBehind = false;
          this.tpsCamera.orbitReturnTime = Infinity;
        }
        this.character.setFirstPersonMode(mode === 'first');
        this.showCameraMode(mode);
      }
      if (k === 'Space') {
        this.input.jump = true;
        if (this.physics.isSwinging) {
          // Detach without manufacturing extra momentum.
          this.input.webHold = false;
          this.physics.releaseSwing();
        }
      }
      if (k === 'KeyF') this.input.wallRun = true;
      if (k === 'KeyE') {
        this.physics.performAirJump(this.camera);
      }
      if (k === 'KeyT') this.physics.performAirTrick();
      if (k === 'KeyM') this.toggleMute();
      if (k === 'KeyH') this.toggleHelp();
      if (k === 'Escape') this.togglePause();
    });

    window.addEventListener('keyup', (e) => {
      const k = e.code;
      if (k === 'KeyW' || k === 'ArrowUp') this.input.forward = false;
      if (k === 'KeyS' || k === 'ArrowDown') this.input.backward = false;
      if (k === 'KeyA' || k === 'ArrowLeft') {
        this.input.left = false;
        this.input.strafe = this.input.right ? 1 : 0;
      }
      if (k === 'KeyD' || k === 'ArrowRight') {
        this.input.right = false;
        this.input.strafe = this.input.left ? -1 : 0;
      }
      if (k === 'ShiftLeft' || k === 'ShiftRight') this.input.sprint = false;
      if (k === 'Space') this.input.jump = false;
      if (k === 'KeyF') this.input.wallRun = false;
    });

    // Mouse Buttons
    window.addEventListener('mousedown', (e) => {
      if (!this.isPlaying || this.isPaused) return;
      if (e.target !== this.canvas) return;
      this.audio.ensureContext();

      if (e.button === 0) {
        // Left click fires and latches the web until the swing is released.
        this.physics.setWebAimPoint(
          e.clientX,
          e.clientY,
          this.canvas.getBoundingClientRect(),
          document.pointerLockElement === this.canvas
        );
        this.physics.findBestAnchor(this.camera);
        this.input.webTap = true;
        this.input.webHold = true;
        if (this.physics.bestAnchorCandidate) {
          this.vfx.spawnWebImpact(this.physics.bestAnchorCandidate);
        }
      } else if (e.button === 2) {
        // Right click zips toward the cursor, or the center under pointer lock.
        this.physics.setWebAimPoint(
          e.clientX,
          e.clientY,
          this.canvas.getBoundingClientRect(),
          document.pointerLockElement === this.canvas
        );
        if (this.physics.performAirJump(this.camera, this.physics.webAimNdc) && this.physics.zipAnchor) {
          this.vfx.spawnWebImpact(this.physics.zipAnchor);
        }
      }
      if (e.button === 1 && document.pointerLockElement !== this.canvas) {
        this.cameraDragActive = true;
        this.lastMousePosition = { x: e.clientX, y: e.clientY };
      }
    });

    window.addEventListener('mouseup', (e) => {
      this.cameraDragActive = false;
      this.lastMousePosition = null;
      if (e.button === 0) {
        // A left-click latches the web. Space is the explicit swing-release action.
        if (!this.physics?.isSwinging) this.input.webHold = false;
      }
    });

    // Prevent default context menu on right click
    window.addEventListener('contextmenu', (e) => e.preventDefault());

    // Mouse-wheel zoom, matching the on-screen controls.
    this.canvas.addEventListener('wheel', (e) => {
      if (!this.isPlaying || this.isPaused) return;
      e.preventDefault();
      this.tpsCamera.handleWheel(e.deltaY);
    }, { passive: false });

    // Mouse Look (Pointer Lock)
    window.addEventListener('mousemove', (e) => {
      if (document.pointerLockElement === this.canvas) {
        this.tpsCamera.handleMouseMove(e.movementX, e.movementY);
      } else if (this.isPlaying && !this.isPaused && this.cameraDragActive && this.lastMousePosition) {
        const dx = e.clientX - this.lastMousePosition.x;
        const dy = e.clientY - this.lastMousePosition.y;
        this.lastMousePosition = { x: e.clientX, y: e.clientY };
        this.tpsCamera.handleMouseMove(dx, dy);
      }
    });

    document.addEventListener('pointerlockchange', () => {
      const locked = document.pointerLockElement === this.canvas;
      if (this.hadPointerLock && !locked && this.isPlaying && !this.isPaused) {
        this.setPaused(true);
      }
      this.hadPointerLock = locked;
    });

    // Canvas click to resume / lock pointer
    this.canvas.addEventListener('click', () => {
      if (this.isPlaying && document.pointerLockElement !== this.canvas) {
        if (this.pointerLockWanted) {
        Promise.resolve(this.canvas.requestPointerLock?.()).catch(() => {});
        }
        this.setPaused(false);
      }
    });
  }

  initUIListeners() {
    // Start Game Button
    const btnStart = document.getElementById('btn-start-game');
    const startAction = (lock = true) => {
      if (!this.character.isLoaded || !this.assetsReady) return;
      this.audio.ensureContext();
      if (this.clickToPlayOverlay) this.clickToPlayOverlay.classList.add('hidden');
      this.isPlaying = true;
      this.pointerLockWanted = lock;
      this.setPaused(false);
      if (lock) Promise.resolve(this.canvas.requestPointerLock?.()).catch(() => {});
    };

    if (btnStart) btnStart.addEventListener('click', () => startAction(true));
    document.getElementById('btn-start-drag')?.addEventListener('click', () => startAction(false));
    if (this.clickToPlayOverlay) {
      this.clickToPlayOverlay.addEventListener('click', (e) => {
        if (e.target.tagName !== 'BUTTON') startAction();
      });
    }

    // Sound toggle button
    const btnSound = document.getElementById('btn-sound');
    if (btnSound) {
      btnSound.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggleMute();
      });
    }

    // Fullscreen toggle button
    const btnFullscreen = document.getElementById('btn-fullscreen');
    if (btnFullscreen) {
      btnFullscreen.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      });
    }

    // Help toggle button
    const btnHelp = document.getElementById('btn-help-toggle');
    if (btnHelp) {
      btnHelp.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggleHelp();
      });
    }

  }

  showCameraMode(mode) {
    const toast = document.getElementById('camera-mode-toast');
    if (!toast) return;
    const labels = { close: '근접 추적 시점', follow: '기본 3인칭 시점', swing: '원거리 스윙 시점', first: '1인칭 시점' };
    toast.textContent = labels[mode] || labels.follow;
    toast.classList.add('visible');
    clearTimeout(this.cameraModeToastTimer);
    this.cameraModeToastTimer = setTimeout(() => toast.classList.remove('visible'), 1300);
  }

  toggleMute() {
    const isMuted = this.audio.toggleMute();
    const soundIcon = document.getElementById('sound-icon');
    if (soundIcon) soundIcon.textContent = isMuted ? '🔇' : '🔊';
  }

  toggleHelp() {
    const guide = document.getElementById('controls-guide');
    if (guide) {
      guide.style.display = guide.style.display === 'none' ? 'block' : 'none';
    }
  }

  togglePause() {
    if (!this.isPlaying) return;
    this.setPaused(!this.isPaused);
    if (!this.isPaused && this.pointerLockWanted) {
      Promise.resolve(this.canvas.requestPointerLock?.()).catch(() => {});
    }
  }

  setPaused(paused) {
    this.isPaused = paused;
    if (paused) this.clearInput();
    if (paused) this.audio.setWindSpeed(0);
    if (this.clickToPlayOverlay) {
      if (this.isPaused) {
        this.clickToPlayOverlay.classList.remove('hidden');
      } else {
        this.clickToPlayOverlay.classList.add('hidden');
      }
    }
  }

  clearInput() {
    for (const key of Object.keys(this.input)) this.input[key] = key === 'strafe' ? 0 : false;
    this.cameraDragActive = false;
    if (this.physics) this.physics.clearPendingInput();
  }

  showStuntNotice(name, pts) {
    if (this.webStatusText) {
      const original = this.webStatusText.textContent;
      this.webStatusText.textContent = `★ ${name} +${pts} ★`;
      this.webStatusText.style.color = '#ffbe00';
      setTimeout(() => {
        if (this.webStatusText) {
          this.webStatusText.style.color = '';
          this.updateHUD(this.physics.velocity.length() * 3.6, this.physics.position.y, this.physics.state);
        }
      }, 1400);
    }
  }

  updateHUD(speedKmh, altitude, state) {
    // 1. Speedometer
    if (this.speedDisplay) {
      this.speedDisplay.textContent = Math.round(speedKmh);
    }
    if (this.speedBarFill) {
      const speedPct = Math.min(speedKmh / 120, 1) * 100;
      this.speedBarFill.style.width = `${speedPct}%`;
    }

    // 2. Altitude
    if (this.altDisplay) {
      this.altDisplay.textContent = Math.round(altitude);
    }
    if (this.altBarFill) {
      const altPct = Math.min(altitude / 220, 1) * 100;
      this.altBarFill.style.width = `${altPct}%`;
    }

    // 3. Web Status Pill
    if (this.webStatusText && !this.webStatusText.textContent.includes('★')) {
      if (state === 'SWINGING') {
        this.webStatusText.textContent = 'SWINGING';
        if (this.webStatusDot) this.webStatusDot.className = 'status-dot swinging';
      } else if (state === 'WALL_RUNNING') {
        this.webStatusText.textContent = 'WALL RUN';
        if (this.webStatusDot) this.webStatusDot.className = 'status-dot';
      } else if (state === 'FALLING') {
        this.webStatusText.textContent = this.physics.velocity.y < -12 ? 'AIR DIVE' : 'SHORT FALL';
        if (this.webStatusDot) this.webStatusDot.className = 'status-dot';
      } else if (['WEB_ZIP','LANDING','ROLLING','TURNING','JUMPING'].includes(state)) {
        this.webStatusText.textContent = state.replace('_',' ');
        if (this.webStatusDot) this.webStatusDot.className = 'status-dot';
      } else {
        this.webStatusText.textContent = 'WEB READY';
        if (this.webStatusDot) this.webStatusDot.className = 'status-dot';
      }
    }
  }

  animate() {
    requestAnimationFrame(this.animate);

    const rawDelta = Math.min(this.clock.getDelta(), 0.1);
    const delta = rawDelta;

    // Keep streamed city tiles advancing while the start overlay is visible;
    // TilesRenderer performs visibility/LOD work independently of gameplay.
    this.city.update(this.clock.getElapsedTime());
    if (!this.assetsReady && this.character.isLoaded &&
        (!(this.city instanceof UrbanGroundCity) || this.city.isReady)) this.onAssetsLoaded();

    if (this.isPlaying && !this.isPaused) {
      // 1. Update Physics and Character
      const wasSwinging = this.physics.isSwinging;
      this.physics.update(delta, this.input, this.camera);
      if (wasSwinging && !this.physics.isSwinging) this.input.webHold = false;

      // 2. Update 3rd Person Follow Camera
      this.tpsCamera.update(
        rawDelta,
        this.physics.renderPosition,
        this.physics.velocity,
        this.physics.isSwinging,
        this.city.buildingMeshes,
        this.city.raycast?.bind(this.city),
        this.physics.facingAngle
      );

      // 3. Update Visuals & FX
      const speedKmh = this.physics.velocity.length() * 3.6;
      if (this.speedLines) {
        this.speedLines.setSpeed(speedKmh);
      }
      this.vfx.update(delta);
      // 4. Update HUD
      this.updateHUD(speedKmh, this.physics.position.y, this.physics.state);
    }

    // Render 3D Scene
    this.renderer.render(this.scene, this.camera);

    // Render 2D Speed lines overlay
    if (this.speedLines) {
      this.speedLines.render();
    }
  }
}

// Bootstrap application on DOM ready
window.addEventListener('DOMContentLoaded', () => {
  if (new URLSearchParams(location.search).has('motionReview')) {
    import('./MotionReview.js').then(m => m.startMotionReview());
  } else new GameApp();
});
