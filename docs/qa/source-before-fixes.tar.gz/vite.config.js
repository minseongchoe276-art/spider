import { defineConfig } from 'vite';

const urbanTilesProxy = {
  '/urban-tiles': {
    target: 'https://data.map.gov.hk',
    changeOrigin: true,
    secure: true,
    rewrite: (path) => path.replace(/^\/urban-tiles/, ''),
  },
};

export default defineConfig({
  server: {
    host: true,
    port: 5173,
    open: false,
    // The official Hong Kong 3D Tiles endpoint does not currently expose
    // browser CORS headers. Proxy only these read-only tile requests during
    // local development; the upstream data is not copied into the project.
    proxy: urbanTilesProxy,
  },
  // npm run preview must serve the same same-origin proxy as local development.
  preview: { proxy: urbanTilesProxy },
  publicDir: 'public'
});
