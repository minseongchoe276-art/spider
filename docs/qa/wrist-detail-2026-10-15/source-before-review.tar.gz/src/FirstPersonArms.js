import * as THREE from 'three';
import {clone} from 'three/addons/utils/SkeletonUtils.js';
import {boneId} from './MotionRetarget.js';
import {bindTransforms,createHandPoseRig,applyHandPose} from './WebHandPose.js';

const fingers=['thumb','index','middle','ring','pinky'];
function viewHandOrientation(side){
  const forward=new THREE.Vector3(side==='left'?-.02:.02,.85,-.526).normalize();
  const palm=new THREE.Vector3(0,-.526,-.85);palm.addScaledVector(forward,-palm.dot(forward)).normalize();
  return new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(forward,palm).normalize(),forward,palm);
}

function skinHand(source,side) {
  if(!source?.getObjectByProperty('isSkinnedMesh',true))return null;
  const model=clone(source);model.visible=true;model.position.set(0,0,0);model.rotation.set(0,0,0);
  const bind=bindTransforms(model),bones={};
  model.traverse(n=>{if(n.isBone){bones[n.name]=n;const rest=bind.get(n);if(rest){n.position.copy(rest.position);n.quaternion.copy(rest.quaternion);n.scale.copy(rest.scale);}}});
  const hand=Object.values(bones).find(b=>boneId(b.name)===side+'hand');
  if(!hand)return null;
  const meshes=[];model.traverse(n=>{if(n.isMesh)meshes.push(n);});let count=0;
  for(const mesh of meshes){
    if(!mesh.isSkinnedMesh){mesh.removeFromParent();continue;}
    const geometry=mesh.geometry,indices=geometry.index,weights=geometry.attributes.skinWeight,joints=geometry.attributes.skinIndex;
    const selected=mesh.skeleton.bones.map(b=>boneId(b.name).startsWith(side+'hand'));
    const member=vertex=>{let weight=0;for(let k=0;k<4;k++)if(selected[joints.getComponent(vertex,k)])weight+=weights.getComponent(vertex,k);return weight>.35;};
    const kept=[];
    for(let i=0;i<(indices?.count || geometry.attributes.position.count);i+=3){
      const triangle=[0,1,2].map(k=>indices?indices.getX(i+k):i+k);
      if(triangle.every(member))kept.push(...triangle);
    }
    if(!kept.length){mesh.removeFromParent();continue;}
    mesh.geometry=geometry.clone();mesh.geometry.clearGroups();mesh.geometry.setIndex(kept);
    mesh.material=Array.isArray(mesh.material)?mesh.material.map(m=>m.clone()):mesh.material.clone();
    mesh.userData.ownViewMaterial=true;
    mesh.frustumCulled=false;mesh.castShadow=false;count+=kept.length/3;
    // View hands should remain readable even when a wall is close to the camera.
    mesh.renderOrder=2;
  }
  if(!count)return null;
  model.updateMatrixWorld(true);
  const alignment=new THREE.Group();alignment.add(model);
  const orientation=viewHandOrientation(side);
  // Preserve the import's unit conversion while aligning the rigid wrist.
  // Inverting its scale would enlarge both the skin and digit lengths.
  const position=new THREE.Vector3(),rotation=new THREE.Quaternion(),scale=new THREE.Vector3();
  hand.matrixWorld.decompose(position,rotation,scale);
  const wristFrame=new THREE.Matrix4().compose(position,rotation,new THREE.Vector3(1,1,1));
  const transform=orientation.multiply(wristFrame.invert());
  transform.decompose(alignment.position,alignment.quaternion,alignment.scale);
  return {object:alignment,rig:createHandPoseRig(model,bones),bones,triangles:count,model};
}

function fallbackHand(side,material) {
  const object=new THREE.Group(),bones={};
  const palm=new THREE.Mesh(new THREE.SphereGeometry(.047,12,10),material);palm.position.y=.045;palm.scale.set(1,1.2,.48);object.add(palm);
  for(const [i,finger] of fingers.entries()){
    let parent=object;const sign=side==='left'?1:-1;
    for(let joint=1;joint<=4;joint++){
      const bone=new THREE.Bone();bone.name=side+'hand'+finger+joint;
      bone.position.set(joint===1?sign*(i-2)*.02:0,joint===1?(i===0?.025:.083):(i===0?.024:.027),0);parent.add(bone);bones[bone.name]=bone;
      if(joint<4){const part=new THREE.Mesh(new THREE.CapsuleGeometry(.008,.017,3,6),material);part.position.y=.013;bone.add(part);}
      parent=bone;
    }
  }
  object.quaternion.setFromRotationMatrix(viewHandOrientation(side));
  return {object,rig:createHandPoseRig(object,bones),bones,triangles:0,model:object};
}

export function createFirstPersonArm(side,source) {
  const sign=side==='left'?-1:1,arm=new THREE.Group();
  const sleeveMaterial=new THREE.MeshStandardMaterial({color:0x142c50,roughness:.65});
  const cuffMaterial=new THREE.MeshStandardMaterial({color:0x343b46,roughness:.45,metalness:.35});
  const elbow=new THREE.Vector3(sign*.39,-.47,-.15),wrist=new THREE.Vector3(sign*.21,-.18,-.64),axis=wrist.clone().sub(elbow);
  const sleeve=new THREE.Mesh(new THREE.CylinderGeometry(.043,.066,axis.length(),12),sleeveMaterial);
  sleeve.position.copy(elbow).add(wrist).multiplyScalar(.5);sleeve.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),axis.clone().normalize());arm.add(sleeve);
  const cuff=new THREE.Mesh(new THREE.CylinderGeometry(.047,.047,.055,12),cuffMaterial);cuff.position.copy(wrist).addScaledVector(axis.clone().normalize(),-.025);cuff.quaternion.copy(sleeve.quaternion);arm.add(cuff);
  const glove=new THREE.Group();glove.name=side+'Glove';glove.position.copy(wrist);arm.add(glove);
  const hand=skinHand(source,side) || fallbackHand(side,new THREE.MeshStandardMaterial({color:0xb51e32,roughness:.55}));glove.add(hand.object);
  const anchor=new THREE.Object3D();anchor.name=side+'WebShooter';anchor.position.copy(wrist);arm.add(anchor);
  arm.userData.hand=hand;arm.userData.side=side;
  arm.traverse(node=>{if(node.isMesh)node.renderOrder=2;});
  return {arm,anchor,glove};
}

export function poseFirstPersonFingers(arm,shoot,grip,combat) {
  const hand=arm.userData.hand,side=arm.userData.side;
  const fighting=!!combat && !['slam','slamLand','hit','hitHead'].includes(combat.key);
  const firing=fighting?0:shoot,closed=fighting?1:grip,relaxed=Math.max(0,1-firing-closed);
  applyHandPose(hand.rig,side,firing,closed,{absolute:true,relaxed});
}

export function prepareFirstPersonDepth(rig){
  let frame=-1;rig.renderOrder=100;
  rig.traverse(node=>{if(node.isMesh){node.renderOrder=100;node.frustumCulled=false;
    // Render the viewmodel after world geometry, retaining depth tests between
    // its own fingers. Disabling material.depthTest makes folded digits draw
    // through each other and disabling it on a shared suit affects opponents.
    node.onBeforeRender=renderer=>{if(frame!==renderer.info.render.frame){frame=renderer.info.render.frame;renderer.clearDepth();}};
  }});
}

export function disposeFirstPersonRig(rig) {
  const geometries=new Set(),materials=new Set(),skeletons=new Set();
  rig?.traverse(node=>{
    if(node.isSkinnedMesh){geometries.add(node.geometry);skeletons.add(node.skeleton);
      if(node.userData.ownViewMaterial)for(const m of Array.isArray(node.material)?node.material:[node.material])materials.add(m);}
    else if(node.isMesh){geometries.add(node.geometry);for(const m of Array.isArray(node.material)?node.material:[node.material])materials.add(m);}
  });
  geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());skeletons.forEach(s=>s.dispose());rig?.removeFromParent();
}
