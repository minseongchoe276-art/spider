import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { retargetMotion, prepareMotion, boneId } from './MotionRetarget.js';
import { MOTIONS, STRIDES, GROUNDED } from './MotionCatalog.js';
import { fetchAsset } from './AssetLoader.js';

export class Character {
  constructor(scene, onProgress, onLoaded) {
    this.scene = scene;
    this.onProgress = onProgress;
    this.onLoaded = onLoaded;
    this.group = new THREE.Group();
    this.group.name = 'SpiderManGroup';
    this.scene.add(this.group);

    this.model = null;
    this.mixer = null;
    this.actions = {};
    this.activeAction = null;
    this.bones = {};
    this.isLoaded = false;

    // Hands for alternating web shooting
    this.rightHand = null;
    this.leftHand = null;
    this.currentHand = 'right';
    this.webShotTimer = 0;
    this.webShotAnchor = null;
    this.persistentWebAnchor = null;
    this.firstPersonRig = null;
    this.firstPersonHands = [];
    this.isFirstPerson = false;

    // Procedural swing / trick tilt
    this.bodyRoll = 0;
    this.bodyPitch = 0;
    this.trickRotation = 0;
    this.isTricking = false;
    this.targetFacingAngle = 0;
    this.idleTime = 0;
    this.lastState = null;
    this.pendingTurn = null;
    this.landingSpeed = 0;

    // Web rope visual
    this.initWebVisual();

    // Start loading models and animations
    this.loadCharacter();
  }

  initWebVisual() {
    // 3D Web Strand using dynamic Curve / Tube or Cylinder
    const maxPoints = 20;
    const positions = new Float32Array(maxPoints * 3);
    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const mat = new THREE.LineBasicMaterial({
      color: 0xffffff,
      linewidth: 3,
      transparent: true,
      opacity: 0.95
    });

    this.webLine = new THREE.Line(geom, mat);
    this.webLine.frustumCulled = false;
    this.webLine.visible = false;
    this.scene.add(this.webLine);
    const secondGeom = new THREE.BufferGeometry();
    secondGeom.setAttribute('position', new THREE.BufferAttribute(new Float32Array(maxPoints * 3), 3));
    this.webLineOffhand = new THREE.Line(secondGeom, mat);
    this.webLineOffhand.frustumCulled = false;
    this.webLineOffhand.visible = false;
    this.scene.add(this.webLineOffhand);

    // Glowing core ribbon / web cylinder for high-visibility 3D look
    const webMeshGeom = new THREE.CylinderGeometry(0.04, 0.04, 1, 6);
    const webMeshMat = new THREE.MeshBasicMaterial({
      color: 0xf0f8ff,
      transparent: true,
      opacity: 0.9
    });
    this.webMesh = new THREE.Mesh(webMeshGeom, webMeshMat);
    this.webMesh.visible = false;
    this.scene.add(this.webMesh);
    this.webMeshOffhand = new THREE.Mesh(webMeshGeom, webMeshMat);
    this.webMeshOffhand.visible = false;
    this.scene.add(this.webMeshOffhand);
  }

  setFirstPersonCamera(camera) {
    this.firstPersonRig = new THREE.Group();
    this.firstPersonRig.name = 'SpiderManFirstPersonArms';
    camera.add(this.firstPersonRig);
    const sleeveMat = new THREE.MeshStandardMaterial({ color: 0x12345f, roughness: 0.68, metalness: 0.05 });
    const gloveMat = new THREE.MeshStandardMaterial({ color: 0xb51e32, roughness: 0.52, metalness: 0.04 });
    const cuffMat = new THREE.MeshStandardMaterial({ color: 0xdbe8f4, roughness: 0.45, metalness: 0.1 });
    for (const side of [-1, 1]) {
      const elbow = new THREE.Vector3(side * 0.53, -0.55, -0.22);
      const wrist = new THREE.Vector3(side * 0.29, -0.31, -0.67);
      const segment = new THREE.Group();
      const axis = wrist.clone().sub(elbow);
      const sleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.13, axis.length(), 10), sleeveMat);
      sleeve.position.copy(elbow).add(wrist).multiplyScalar(0.5);
      sleeve.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis.clone().normalize());
      sleeve.castShadow = true;
      segment.add(sleeve);
      const glove = new THREE.Mesh(new THREE.SphereGeometry(0.105, 12, 10), gloveMat);
      glove.position.copy(wrist);
      glove.scale.set(1, 0.82, 1.22);
      segment.add(glove);
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.105, 0.055, 10), cuffMat);
      cuff.position.copy(wrist).addScaledVector(axis.clone().normalize(), -0.085);
      cuff.quaternion.copy(sleeve.quaternion);
      segment.add(cuff);
      this.firstPersonRig.add(segment);
      const anchor = new THREE.Object3D();
      anchor.position.copy(wrist);
      this.firstPersonRig.add(anchor);
      this.firstPersonHands.push(anchor);
    }
    this.firstPersonRig.visible = false;
  }

  setFirstPersonMode(enabled) {
    this.isFirstPerson = !!enabled;
    if (this.firstPersonRig) this.firstPersonRig.visible = this.isFirstPerson;
    if (this.model) this.model.visible = !this.isFirstPerson;
    if (this.placeholder) this.placeholder.visible = !this.isFirstPerson;
  }

  async loadCharacter() {
    // 1. Placeholder while loading so player has instant visual feedback
    const placeholderGeom = new THREE.CapsuleGeometry(0.35, 1.1, 8, 16);
    const placeholderMat = new THREE.MeshStandardMaterial({
      color: 0xff2a3a,
      roughness: 0.3,
      metalness: 0.5
    });
    this.placeholder = new THREE.Mesh(placeholderGeom, placeholderMat);
    this.placeholder.position.y = 0.9;
    this.group.add(this.placeholder);

    const gltfLoader = new GLTFLoader();
    const fbxLoader = new FBXLoader();

    try {
      this.onProgress?.(30, '스파이더맨 3D 모델 불러오는 중...');
      // Load Spider-Man GLB
      const gltf = await gltfLoader.parseAsync(await fetchAsset('/models/spiderman.glb'), '/models/');

      this.model = gltf.scene;
      // The exported GLB is already roughly human-sized (about 2 world units tall).
      // Scaling it to 0.012 made the character only a few centimetres tall and
      // effectively invisible beside the city.
      this.model.scale.setScalar(1);
      this.model.position.y = 0;

      // Enable shadows and find bones
      this.model.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
          if (child.material) {
            child.material.roughness = 0.45;
            child.material.metalness = 0.3;
          }
        }
        if (child.isBone) {
          this.bones[child.name] = child;
          if (boneId(child.name) === 'righthand') {
            this.rightHand = child;
          }
          if (boneId(child.name) === 'lefthand') {
            this.leftHand = child;
          }
        }
      });

      // Remove placeholder and add model
      this.group.remove(this.placeholder);
      this.placeholder.geometry.dispose();
      this.placeholder.material.dispose();
      this.group.add(this.model);

      this.mixer = new THREE.AnimationMixer(this.model);

      // Embedded animation if available
      if (gltf.animations && gltf.animations.length > 0) {
        const defaultClip = gltf.animations[0];
        defaultClip.name = 'default';
        const defaultAction = this.mixer.clipAction(defaultClip);
        this.actions['default'] = defaultAction;
      }

      this.onProgress?.(65, '스윙 및 질주 애니메이션 로드 중...');
      // Load FBX animations
      await this.loadFbxAnimations(fbxLoader);

      // Start from a clean state. The state machine below selects the proper
      // downloaded Mixamo clip after the character enters the game.
      this.stopAnimation();

      this.isLoaded = true;
      this.onProgress?.(100, '준비 완료!');
      this.onLoaded?.();
      console.log('Spider-Man character and animations successfully loaded!');
    } catch (err) {
      console.warn('Failed loading GLTF/FBX models, keeping high-poly proxy:', err);
      this.loadWarning = '캐릭터 리소스를 불러오지 못해 대체 캐릭터로 실행합니다.';
      this.isLoaded = true;
      this.onProgress?.(100, this.loadWarning);
      this.onLoaded?.();
    }
  }

  async loadFbxAnimations(fbxLoader) {
    const animFiles = MOTIONS;
    const sources = new Map();

    for (const item of animFiles) {
      try {
        let clip;
        try {
          const data = JSON.parse(new TextDecoder().decode(await fetchAsset(`/motions/${item.key}.json`)));
          clip = THREE.AnimationClip.parse(data);
          clip.userData = data.userData || {};
          if (!Number.isFinite(clip.duration) || clip.duration <= 0 || !(clip.userData.matchedBones >= 20) || !clip.tracks.length ||
              !clip.tracks.every(track => [...track.values].every(Number.isFinite))) throw new Error('Invalid compiled motion');
        } catch {
          // Existing asset folders remain usable without precompiled tracks.
        if (!sources.has(item.url)) {
          sources.set(item.url, fetchAsset(item.url));
        }
        const fbx = fbxLoader.parse(await sources.get(item.url), '/models/');

        if (fbx.animations && fbx.animations.length > 0) {
          const sourceClip = fbx.animations.find(c => c.duration > 0 && c.tracks.length > 0);
          if (!sourceClip) throw new Error('No animated take in FBX');
          clip = retargetMotion(this.model, fbx, sourceClip);
          clip = prepareMotion(clip, item.key, this.bones);
        }
        }
        if (clip) {
          console.info('Motion verified', item.key, clip.userData.matchedBones, 'bones');
          clip.name = item.key;
          const action = this.mixer.clipAction(clip);

          if (item.loop) {
            action.setLoop(THREE.LoopRepeat);
          } else {
            action.setLoop(THREE.LoopOnce);
            action.clampWhenFinished = true;
          }

          this.actions[item.key] = action;
        }
      } catch (e) {
        this.loadWarning = '일부 모션을 불러오지 못했습니다. 가능한 대체 모션을 사용합니다.';
        console.warn(`Could not load animation ${item.key}:`, e);
      }
    }
  }


  fadeToAction(name, duration = 0.2) {
    if (!this.actions[name]) {
      const alternatives = {
        walk: ['jog', 'regularRun', 'run'], jog: ['walk', 'regularRun', 'run'],
        regularRun: ['run', 'jog', 'walk'], run: ['regularRun', 'jog', 'walk'],
        swing: ['jump', 'drop', 'fall'], jump: ['drop', 'fall'],
        drop: ['fall', 'jump'], fall: ['drop', 'jump'],
        land: ['idle'], roll: ['land', 'idle'], stop: ['idle'], runStop: ['stop', 'idle'],
        turnLeft: ['idle'], turnRight: ['idle'], idle: ['default'],
      };
      name = [...(alternatives[name] || []), 'idle', 'default'].find(key => this.actions[key]);
      if (!name) { this.stopAnimation(); return; }
    }
    const previousAction = this.activeAction;
    const nextAction = this.actions[name];

    if (previousAction !== nextAction) {
      if (previousAction) {
        if (duration > 0) previousAction.fadeOut(duration);
        else previousAction.stop();
      }
      nextAction
        .reset()
        .setEffectiveTimeScale(1)
        .setEffectiveWeight(1)
        .play();
      if (duration > 0) nextAction.fadeIn(duration);
      this.activeAction = nextAction;
      if (previousAction && STRIDES.includes(name) &&
          STRIDES.includes(previousAction.getClip().name)) {
        nextAction.time = (previousAction.time / previousAction.getClip().duration % 1) * nextAction.getClip().duration;
      }
    }
  }

  stopAnimation() {
    if (this.activeAction) {
      this.activeAction.fadeOut(0.12);
      this.activeAction.stop();
      this.activeAction = null;
    }
  }

  requestTurn(direction) {
    if (direction === 'left' || direction === 'right') {
      this.pendingTurn = direction;
    }
  }
  getWristPosition() {
    const hand = this.currentHand === 'right' ? this.rightHand : this.leftHand;
    if (hand) {
      const pos = new THREE.Vector3();
      hand.getWorldPosition(pos);
      return pos;
    }
    // Fallback: slight offset from character center
    return this.group.position.clone().add(new THREE.Vector3(0.3, 1.2, 0.3));
  }

  toggleHand() {
    this.currentHand = this.currentHand === 'right' ? 'left' : 'right';
  }

  fireWeb(anchor) {
    if (!anchor) return;
    this.webShotAnchor = anchor.clone();
    this.webShotTimer = 0.38;
    this.persistentWebAnchor = anchor.clone();
    this.reachBothWebAnchors(this.webShotAnchor);
    this.updateWeb(true, this.webShotAnchor);
  }

  updateWeb(isSwinging, anchorPos) {
    if (!isSwinging || !anchorPos) {
      this.webLine.visible = false;
      this.webMesh.visible = false;
      if (this.webLineOffhand) this.webLineOffhand.visible = false;
      if (this.webMeshOffhand) this.webMeshOffhand.visible = false;
      return;
    }

    const fallback = this.group.position;
    const wrists = this.isFirstPerson && this.firstPersonHands.length === 2
      ? this.firstPersonHands.map(hand => hand.getWorldPosition(new THREE.Vector3()))
      : [
        this.rightHand?.getWorldPosition(new THREE.Vector3()) || fallback.clone().add(new THREE.Vector3(0.22, 1.2, 0)),
        this.leftHand?.getWorldPosition(new THREE.Vector3()) || fallback.clone().add(new THREE.Vector3(-0.22, 1.2, 0))
      ];
    this.updateWebStrand(this.webLine, this.webMesh, wrists[0], anchorPos);
    if (this.webLineOffhand && this.webMeshOffhand)
      this.updateWebStrand(this.webLineOffhand, this.webMeshOffhand, wrists[1], anchorPos);
  }

  updateWebStrand(line, mesh, wrist, anchorPos) {
    line.visible = true;
    mesh.visible = true;
    const dir = new THREE.Vector3().subVectors(anchorPos, wrist);
    const len = dir.length();
    mesh.position.copy(wrist).add(anchorPos).multiplyScalar(0.5);
    mesh.scale.set(1, len, 1);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    const posAttr = line.geometry.attributes.position;
    const pts = 10;
    for (let i = 0; i < pts; i++) {
      const t = i / (pts - 1);
      const p = new THREE.Vector3().lerpVectors(wrist, anchorPos, t);
      p.y -= Math.sin(t * Math.PI) * Math.min(len * 0.03, 1.5);
      posAttr.setXYZ(i, p.x, p.y, p.z);
    }
    posAttr.needsUpdate = true;
    line.geometry.setDrawRange(0, pts);
  }

  triggerAirTrick() {
    this.isTricking = true;
    this.trickRotation = 0;
  }

  update(delta, state, velocity, anchorPos) {
    this.webShotTimer = Math.max(0, this.webShotTimer - delta);
    if (this.webShotTimer === 0) this.webShotAnchor = null;
    if (!this.mixer || !this.model) {
      const shotAnchor = this.webShotTimer > 0 ? this.webShotAnchor : null;
      const attached = ['SWINGING', 'WEB_ZIP'].includes(state) && !!anchorPos;
      const visibleAnchor = attached ? anchorPos : (this.persistentWebAnchor || shotAnchor);
      this.updateWeb(!!visibleAnchor, visibleAnchor);
      if (this.placeholder) this.placeholder.rotation.y = this.targetFacingAngle;
      return;
    }
    const horizontalSpeed = Math.hypot(velocity.x, velocity.z);
    const grounded = GROUNDED.includes(state);
    const previous = this.lastState;
    const playing = name => !!this.actions[name] && this.activeAction === this.actions[name] &&
      this.activeAction.time < this.activeAction.getClip().duration - 0.05;
    let name = 'idle';
    if (state === 'SWINGING') name = 'swing';
    else if (state === 'WALL_RUNNING') name = 'run';
    else if (state === 'WEB_ZIP') name = 'jump';
    else if (state === 'TURNING') name = this.pendingTurn === 'left' ? 'turnLeft' : 'turnRight';
    else if (state === 'LANDING') name = 'land';
    else if (state === 'ROLLING') name = 'roll';
    else if (state === 'JUMPING') name = 'jump';
    else if (state === 'FALLING') name = velocity.y < -12 && !(this.contactTime < 0.3) ? 'fall' : 'drop';
    else if (state === 'IDLE') {
      if (previous === 'SPRINTING') name = 'runStop';
      else if (previous === 'RUNNING') name = 'stop';
      else if (playing('runStop')) name = 'runStop';
      else if (playing('stop')) name = 'stop';
    } else name = state === 'SPRINTING' ? 'run' :
      horizontalSpeed > 3.3 ? 'regularRun' : horizontalSpeed > 1.9 ? 'jog' : 'walk';
    this.fadeToAction(name, ['LANDING','ROLLING'].includes(state) ? 0.06 : grounded ? 0.18 : 0.12);
    if (STRIDES.includes(name)) {
      const measuredSpeed = this.activeAction?.getClip().userData?.nominalSpeed;
      const strideSpeed = measuredSpeed > 0.1 ? measuredSpeed : ({walk:1.6,jog:2.4,regularRun:4.5,run:6.5}[name]);
      this.activeAction?.setEffectiveTimeScale(THREE.MathUtils.clamp(
        horizontalSpeed / strideSpeed, 0.15, 1.6));
    }
    this.mixer.update(delta);
    this.lastState = state;
    this.idleTime += delta;
    if (grounded) { this.isTricking = false; this.trickRotation = 0; }
    if (this.isTricking) {
      this.trickRotation = Math.min(Math.PI * 2, this.trickRotation + delta * 10);
      if (this.trickRotation >= Math.PI * 2) {
        this.isTricking = false; this.trickRotation = 0;
      }
    }
    const yaw = state === 'SWINGING' && horizontalSpeed > 0.5
      ? Math.atan2(velocity.x, velocity.z) : this.targetFacingAngle;
    const currentYaw = this.visualYaw ?? yaw;
    this.visualYaw = currentYaw + Math.atan2(Math.sin(yaw - currentYaw),
      Math.cos(yaw - currentYaw)) * (1 - Math.exp(-12 * delta));
    this.bodyPitch = THREE.MathUtils.damp(this.bodyPitch,
      state === 'WEB_ZIP' ? -0.55 : state === 'SWINGING' ? THREE.MathUtils.clamp(-velocity.y * 0.015, -0.45, 0.45) : 0, 10, delta);
    this.model.rotation.set(this.bodyPitch + this.trickRotation, this.visualYaw, 0, 'YXZ');
    if (state === 'WALL_RUNNING' && this.wallNormal) {
      // A humanoid's local Y is its spine, not the sole normal. Swapping
      // Y with the wall normal laid the entire character across the wall.
      const forward = this.wallNormal.clone().normalize().negate();
      const up = new THREE.Vector3(0,1,0);
      const right = new THREE.Vector3().crossVectors(up,forward).normalize();
      this.model.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,up,forward));
    }
    // Physics keeps a 10cm foot clearance; the rendered soles should sit on
    // the support surface, not inherit that collision padding.
    this.model.position.y = grounded && state !== 'ROLLING' ? -0.1 : 0;
    this.group.updateMatrixWorld(true);
    if (name === 'idle' && state === 'IDLE' && horizontalSpeed < 0.05) {
      this.plantIdleFeet(delta);
    } else {
      this.idlePlantDelay=0; this.idleFootAnchors=null;
    }
    const firingAnchor = this.webShotTimer > 0 ? this.webShotAnchor : null;
    if (state === 'SWINGING' && anchorPos) this.reachBothWebAnchors(anchorPos);
    else if (state === 'WEB_ZIP' && anchorPos) this.reachBothWebAnchors(anchorPos);
    else if (firingAnchor) this.reachBothWebAnchors(firingAnchor);
    if (state === 'WALL_RUNNING' && this.wallNormal) {
      const side = new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),this.wallNormal).normalize();
      const hand = this.currentHand;
      for (const [which,sign] of [['left',-1],['right',1]]) {
        this.currentHand=which;
        this.reachWebAnchor(this.group.position.clone().addScaledVector(this.wallNormal,-0.7)
          .add(new THREE.Vector3(0,1.4,0)).addScaledVector(side,sign*0.35));
      }
      this.currentHand=hand;
    }
    const attached = ['SWINGING','WEB_ZIP'].includes(state) && !!anchorPos;
    const visibleAnchor = attached ? anchorPos : (this.persistentWebAnchor || firingAnchor);
    this.updateWeb(!!visibleAnchor, visibleAnchor);
  }

  reachWebAnchor(anchor) {
    const prefix = this.currentHand === 'right' ? 'right' : 'left';
    const find = id => Object.values(this.bones || {}).find(b => boneId(b.name) === prefix + id);
    const arm = find('arm'), forearm = find('forearm'), hand = find('hand');
    if (!arm || !forearm || !hand) return;
    this.solveLimb(arm,forearm,hand,anchor,0.95);
  }

  reachBothWebAnchors(anchor) {
    const previousHand = this.currentHand;
    for (const hand of ['left', 'right']) {
      this.currentHand = hand;
      this.reachWebAnchor(anchor);
    }
    this.currentHand = previousHand;
  }

  plantIdleFeet(delta) {
    const root = this.group.getWorldPosition(new THREE.Vector3());
    if (this.idleFootRoot && this.idleFootRoot.distanceToSquared(root)>0.01) {
      this.idleFootAnchors = null; this.idlePlantDelay = 0;
    }
    this.idleFootRoot = root.clone();
    this.idlePlantDelay=(this.idlePlantDelay || 0)+delta;
    if (this.idlePlantDelay < 0.22) return;
    const find = id => Object.values(this.bones || {}).find(b => boneId(b.name) === id);
    for (const side of ['left','right']) {
      const upper=find(side+'upleg'),lower=find(side+'leg'),foot=find(side+'foot');
      if (!upper || !lower || !foot) continue;
      this.idleFootAnchors ||= {};
      this.idleFootAnchors[side] ||= foot.getWorldPosition(new THREE.Vector3());
      const goal=this.idleFootAnchors[side].clone();
      const probe = new THREE.Vector3(goal.x, root.y+0.4, goal.z);
      const surface = this.groundProbe?.(probe);
      goal.y=surface !== undefined && surface !== null && Math.abs(surface-root.y)<0.35
        ? surface+0.01 : root.y+0.01;
      const current=foot.getWorldPosition(new THREE.Vector3());
      goal.lerpVectors(current,goal,THREE.MathUtils.clamp((this.idlePlantDelay-0.22)/0.18,0,1));
      this.solveLimb(upper,lower,foot,goal,0.999);
    }
  }

  solveLimb(arm,forearm,hand,anchor,maxReach=0.95) {
    const shoulder = arm.getWorldPosition(new THREE.Vector3());
    const elbow = forearm.getWorldPosition(new THREE.Vector3());
    const wrist = hand.getWorldPosition(new THREE.Vector3());
    const a = shoulder.distanceTo(elbow), b = elbow.distanceTo(wrist);
    const direction = anchor.clone().sub(shoulder).normalize();
    if (a < 1e-6 || b < 1e-6 || anchor.distanceToSquared(shoulder)<1e-8) return;
    const length = THREE.MathUtils.clamp(anchor.distanceTo(shoulder), Math.abs(a-b)+0.001, (a+b)*maxReach);
    const target = shoulder.clone().addScaledVector(direction,length);
    let bend = elbow.clone().sub(shoulder).addScaledVector(direction,-elbow.clone().sub(shoulder).dot(direction));
    if (bend.lengthSq() < 1e-6) bend = new THREE.Vector3(0,0,1).addScaledVector(direction,-direction.z);
    bend.normalize();
    const along = (a*a + length*length - b*b) / (2*length);
    const elbowTarget = shoulder.clone().addScaledVector(direction,along)
      .addScaledVector(bend,Math.sqrt(Math.max(0,a*a-along*along)));
    const rotate = (bone, child, goal) => {
      const start = bone.getWorldPosition(new THREE.Vector3());
      const from = child.getWorldPosition(new THREE.Vector3()).sub(start).normalize();
      const to = goal.clone().sub(start).normalize();
      const world = new THREE.Quaternion().setFromUnitVectors(from,to).multiply(bone.getWorldQuaternion(new THREE.Quaternion()));
      bone.quaternion.copy(bone.parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(world));
      bone.updateMatrixWorld(true);
    };
    rotate(arm,forearm,elbowTarget); rotate(forearm,hand,target);
  }
}
