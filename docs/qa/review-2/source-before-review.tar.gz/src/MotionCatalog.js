// Original takes remain reviewable; derivatives are explicitly labelled.
export const MOTIONS = [
  ['idle','Idle',true], ['walk','Walking',true], ['jog','Jogging',true],
  ['regularRun','Running',true], ['run','Fast Run',true],
  ['stop','Female Stop Walking'], ['runStop','Run To Stop'],
  ['turnLeft','Left Turn'], ['turnRight','Right Turn'],
  ['jump','Standing Jump'], ['land','Standing Jump'],
  ['jumpDown','Jumping Down (1)'], ['drop','Jumping Down (1)'],
  ['jumpDownVariant','Jumping Down'], ['swing','Rope Swinging',true],
  ['fall','Falling (2)',true], ['fallVariant','Falling',true],
  ['fallIdle','Falling Idle',true], ['roll','Falling To Roll'],
  ['injuredIdle','Injured Idle',true],
].map(([key,file,loop=false]) => ({key,url:`/models/${file}.fbx`,loop}));
export const STRIDES = ['walk','jog','regularRun','run'];
export const GROUNDED = ['IDLE','RUNNING','SPRINTING','TURNING','LANDING','ROLLING'];
