import * as THREE from 'three';

export const boneId = name => name.replace(/^mixamorig\d*:?/i, '').toLowerCase();
const restPoses = new WeakMap();

export function prepareMotion(clip, key, bones) {
  const audit = clip.userData;
  // Falling To Roll contains an airborne lead-in. Begin at contact,
  // because the physics controller has already completed the fall.
  if (key === 'roll') clip = THREE.AnimationUtils.subclip(clip, 'roll', 16, Math.floor(clip.duration * 30), 30);
  // Standing Jump includes anticipation and landing. Physics drives
  // takeoff immediately, so use only the airborne portion here.
  if (key === 'jump') clip = THREE.AnimationUtils.subclip(clip, 'jump', 24, 43, 30);
  if (key === 'land') clip = THREE.AnimationUtils.subclip(clip, 'land', 44, 71, 30);
  if (key === 'drop') clip = THREE.AnimationUtils.subclip(clip, 'drop', 0, 16, 30);
  if (key === 'stop') clip = THREE.AnimationUtils.subclip(clip, 'stop', 29, 47, 30);
  if (key === 'swing') {
    // Exclude the takeoff and release/standing portions of this take.
    clip = THREE.AnimationUtils.subclip(clip, 'swing', 15, 75, 30);
  }
  if (['swing','jump','drop'].includes(key)) {
    const hips = Object.values(bones).find(b => boneId(b.name) === 'hips');
    const positionTrack = clip.tracks.find(t => t.name === `${hips.name}.position`);
    for (let i = 0; i < positionTrack.values.length; i += 3) positionTrack.values.set(hips.position.toArray(), i);
  }
  if (key === 'turnLeft' || key === 'turnRight') {
    // Let the controller own heading; remove authored pelvis yaw so it is
    // not added a second time to the model's turn.
    const hips = Object.values(bones).find(b => boneId(b.name) === 'hips');
    const track = clip.tracks.find(t => t.name === `${hips.name}.quaternion`);
    const parent = hips.parent.getWorldQuaternion(new THREE.Quaternion());
    const inverse = parent.clone().invert();
    const first = parent.clone().multiply(new THREE.Quaternion().fromArray(track.values)).invert();
    for (let i=0;i<track.values.length;i+=4) {
      const world = parent.clone().multiply(new THREE.Quaternion().fromArray(track.values,i));
      const relative = world.clone().multiply(first);
      const twist = new THREE.Quaternion(0,relative.y,0,relative.w).normalize();
      inverse.clone().multiply(twist.invert().multiply(world)).normalize().toArray(track.values,i);
    }
  }
  if (['idle','walk','jog','regularRun','run','fall','fallVariant','fallIdle','injuredIdle','swing'].includes(key)) {
    // Blend the last 0.15s into the first pose, avoiding loop snaps.
    for (const track of clip.tracks) {
      for (let i = 0; i < track.times.length; i++) {
        const alpha = THREE.MathUtils.clamp((track.times[i] - clip.duration + 0.15) / 0.15, 0, 1);
        if (!alpha) continue;
        if (track.ValueTypeName === 'quaternion') {
          const q = new THREE.Quaternion().fromArray(track.values, i * 4);
          q.slerp(new THREE.Quaternion().fromArray(track.values), alpha).toArray(track.values, i * 4);
        } else {
          for (let j = 0; j < 3; j++) track.values[i * 3 + j] = THREE.MathUtils.lerp(track.values[i * 3 + j], track.values[j], alpha);
        }
      }
    }
  }
  clip.userData = {...audit};
  if (key === 'roll' && audit.rootMotion) {
    const start = 16 / 30;
    const points = audit.rootMotion.filter(p => p.time >= start);
    const origin = points[0];
    clip.userData.rootMotion = points.map(p => ({
      time:(p.time-origin.time)*clip.duration/(points.at(-1).time-origin.time),
      distance:p.distance-origin.distance,
    }));
  }
  clip.name = key;
  return clip;
}

// Bake Mixamo source world-space rotations into the target's local axes.
// FBX and GLB roots use different units and coordinate systems; track renaming
// alone is not retargeting (in particular, GLB Hips is rotated -90 degrees).
export function retargetMotion(target, source, clip, fps = 30) {
  const targetBones = [], sourceBones = new Map();
  target.traverse(n => { if (n.isBone) targetBones.push(n); });
  source.traverse(n => { if (n.isBone) sourceBones.set(boneId(n.name), n); });
  // Keep imported local rest transforms. skeleton.pose() uses inverse binds
  // that this asset stores in a different mesh coordinate system.
  if (!restPoses.has(target)) restPoses.set(target, targetBones.map(n => ({
    n, p: n.position.clone(), q: n.quaternion.clone(), s: n.scale.clone(),
  })));
  restPoses.get(target).forEach(({ n, p, q, s }) => {
    n.position.copy(p); n.quaternion.copy(q); n.scale.copy(s);
  });
  target.updateMatrixWorld(true);
  source.updateMatrixWorld(true);
  const pairs = targetBones.map(t => {
    const s = sourceBones.get(boneId(t.name));
    return s && { t, s, targetRest: t.getWorldQuaternion(new THREE.Quaternion()),
      sourceInverse: s.getWorldQuaternion(new THREE.Quaternion()).invert(),
      position: t.position.clone(), rotation: t.quaternion.clone(), scale: t.scale.clone(),
      values: [], positions: [] };
  }).filter(Boolean);
  if (!pairs.some(p => boneId(p.t.name) === 'hips') || pairs.length < 20) {
    throw new Error(`Incompatible skeleton: ${pairs.length} matching bones`);
  }
  const hips = pairs.find(p => boneId(p.t.name) === 'hips');
  // These are all Mixamo rigs with the same joint-axis convention, but the
  // target was exported in an A-pose and most sources in a T-pose. Per-joint
  // rest deltas would keep that A-pose offset and fold arms into the torso.
  const rootAlignment = hips.targetRest.clone().multiply(hips.sourceInverse);
  const srcOrigin = hips.s.getWorldPosition(new THREE.Vector3());
  const targetOrigin = hips.t.getWorldPosition(new THREE.Vector3());
  const sourceFoot = sourceBones.get('leftfoot');
  const targetFoot = pairs.find(p => boneId(p.t.name) === 'leftfoot')?.t;
  const ratio = sourceFoot && targetFoot
    ? targetOrigin.distanceTo(targetFoot.getWorldPosition(new THREE.Vector3())) /
      srcOrigin.distanceTo(sourceFoot.getWorldPosition(new THREE.Vector3())) : 0.0254;
  const mixer = new THREE.AnimationMixer(source);
  mixer.clipAction(clip).play();
  const times = [], count = Math.max(2, Math.ceil(clip.duration * fps) + 1);
  const rootSamples = [];
  for (let frame = 0; frame < count; frame++) {
    const time = clip.duration * frame / (count - 1);
    times.push(time);
    // Avoid LoopRepeat wrapping the final sample to the beginning.
    mixer.setTime(Math.min(time, clip.duration - 1e-6));
    source.updateMatrixWorld(true);
    rootSamples.push(hips.s.getWorldPosition(new THREE.Vector3()));
    for (const p of pairs) {
      const world = rootAlignment.clone().multiply(p.s.getWorldQuaternion(new THREE.Quaternion()));
      const parent = p.t.parent.getWorldQuaternion(new THREE.Quaternion()).invert();
      p.t.quaternion.copy(parent.multiply(world)).normalize();
      if (p === hips) {
        const dy = (p.s.getWorldPosition(new THREE.Vector3()).y - srcOrigin.y) * ratio;
        const pos = targetOrigin.clone(); pos.y += dy;
        p.t.position.copy(p.t.parent.worldToLocal(pos));
        p.positions.push(...p.t.position.toArray());
      }
      p.t.updateMatrixWorld(true);
      // Quaternion signs must stay continuous for interpolation and auditing.
      if (p.values.length && p.t.quaternion.dot(new THREE.Quaternion().fromArray(p.values, p.values.length - 4)) < 0) {
        p.t.quaternion.set(...p.t.quaternion.toArray().map(v => -v));
      }
      p.values.push(...p.t.quaternion.toArray());
    }
  }
  const tracks = pairs.map(p => new THREE.QuaternionKeyframeTrack(`${p.t.name}.quaternion`, times, p.values));
  tracks.push(new THREE.VectorKeyframeTrack(`${hips.t.name}.position`, times, hips.positions));
  pairs.forEach(p => { p.t.position.copy(p.position); p.t.quaternion.copy(p.rotation); p.t.scale.copy(p.scale); });
  target.updateMatrixWorld(true);
  mixer.stopAllAction(); mixer.uncacheRoot(source);
  const result = new THREE.AnimationClip(clip.name, clip.duration, tracks);
  const displacement = rootSamples.at(-1).clone().sub(rootSamples[0]);
  result.userData = { matchedBones: pairs.length, unitScale: ratio,
    nominalSpeed: Math.hypot(displacement.x,displacement.z) * ratio / clip.duration,
    rootMotion: rootSamples.map((p,i) => ({time:times[i],distance:Math.hypot(p.x-rootSamples[0].x,p.z-rootSamples[0].z)*ratio})) };
  return result;
}
